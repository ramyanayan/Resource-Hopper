from django.apps import AppConfig


class ResourceHopperConfig(AppConfig):
    name = 'resource_hopper'
