from django import forms
from .models import Resource, Skill 

class EnterResource(forms.ModelForm):
	class Meta:
		model = Resource
		fields = ('resource_fname', 'resource_lname', 'timezone_id', 'language_id')
		labels = {
			"resource_fname": "First Name",
			"resource_lname": "Last Name",
			"timezone_id": "Timezone",
			"language_id": "Language",
		}


class SelectSkill(forms.ModelForm):
	class Meta:
		model = Skill
		fields = ('skill_name',)
		labels = {
			"skill_name": "Skill",
		}

class BuildTeam(forms.Form):
	SKILLS = (
		("1", "CS633 - Requirements"),
		("2", "CS633 - PM"),
		("3", "CS633 - Coding"),
		("4", "CS633 - Testing"),
		("5", "CS633 - UX"),
	)
	skills = forms.MultipleChoiceField(widget=forms.CheckboxSelectMultiple,choices=SKILLS,label="Select Required Skills")




#	fname = forms.CharField()
#	lname = forms.CharField()
#	language = forms.ChoiceField(choices = [('english', 'English'), ('spanish', 'Spanish')])
#	timezone = forms.ChoiceField(choices = [('+11', '+11'), ('+12', '+12')])